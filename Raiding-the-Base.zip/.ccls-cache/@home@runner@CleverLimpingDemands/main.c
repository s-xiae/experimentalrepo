#include <stdio.h>


int main(void)
{
  int input;
  printf("Raiding the Base\nPress 1 to Begin: ");
  scanf("%d", &input);
  if(input == 1)
  {
    printf("You are in a top secret military division. You get assigned a task from general, to infiltrate the hyper clan, which is trying to take over the world.\nYou are really close to their base, and have 6 options:\n1. Bomb\n2. Drill\n3. Teleporter\n4. Sneak in\n5. Cheese\n6. Bean\n");
    scanf("%d", &input);
    if(input == 1)
    {
      printf("You throw a bomb, but then when it explodes, base is unharmed, and there are now some angry hyper clan members shooting at the Helicopter.\nFAIL: Use imploding bombs, one exploding ones.");
      return 0;
    }
    if(input == 2)
    {
      printf("As soon as you attempt to drill into the base, the drill brakes, since the walls are extremely strong.\nFAIL: Okay, now this already is getting ridiculous, and this just started.");
      return 0;
    }
    if(input == 3)
    {
      printf("You teleport into the building.\nYou see 2 guards, and they notice you.\n1. Bean\n2. Sniper Rifle\n3. Disappear\n4. Pistol\n");
    }
    if(input == 4)
    {
      printf("You manage to bypass the guards in the front.\n");
    }
    if(input == 5)
    {
      
    }
    if(input == 6)
    {
      printf("You eat it and nothing happens.\nFAIL: I'll tell you that absolutely nothing happens if eat it.");
      return 0;
    }
  }
  return 0;
}