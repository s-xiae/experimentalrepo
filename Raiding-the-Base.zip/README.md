# **RAIDING THE BASE GUIDE (Not really, but technically is still one)**

### This isn't a cheat sheet.
This is actually an important thing to read before actually playing the game. First, this is a console game, so you play in the console. Press the run button up top, and then follow instructions in console. Press the respective numbers that are part of each option.
### Origins
I created this because I was bored AF. Please don't blame me if this is buggy, since I rushed things so much. This is very similar to Henry Stickmin games, but you don't get those timed option screens. Instead, I just put a timeout option as the first option. Okay, done with how I created this game.
### Endings
I'm not going to spoil the game for you, so I might as well just tell you one thing: There are 3 endings. That's it.
### Game on!
Go on, now start playing this game. Oh, and by the way, when you fail, you have to restart the game to succesfully get past that part. Sorry for the technical issues.